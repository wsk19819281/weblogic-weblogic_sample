package com.ictra.mq;

public class MQConstants {
	public static String MQ_hostname = "uxvenusc020xd01aa.msnet.railb.be";
	public static String MQ_channel = "A447.TO.QMIA00D";
	public static int	MQ_port = 1435;
	public static String MQ_queueManager = "QMIA00D";
	public static String MQ_queue = "AQ.A447.NIS.NOTIFICATION.EVENT";
	  
}
