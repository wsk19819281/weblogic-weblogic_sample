package com.testws.exceptions;

public class MyCustomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7419386997304294762L;

	public MyCustomException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyCustomException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MyCustomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MyCustomException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
